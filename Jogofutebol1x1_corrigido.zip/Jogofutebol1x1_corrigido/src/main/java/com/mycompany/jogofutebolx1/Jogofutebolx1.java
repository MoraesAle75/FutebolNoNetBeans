package com.mycompany.jogofutebolx1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Jogofutebolx1 extends JPanel implements ActionListener, KeyListener {

    private static final int LARGURA = 800;
    private static final int ALTURA = 500;

    // Posições dos Jogadores e Bola
    private int j1X = 100, j1Y = 220;
    private int j2X = 660, j2Y = 220;
    private int bolaX = 390, bolaY = 240;

    // Velocidades da Bola
    private double bolaVX = 0, bolaVY = 0;

    // Placar
    private int golsJ1 = 0;
    private int golsJ2 = 0;

    // Estado de Fim de Jogo
    private boolean jogoTerminou = false;
    private String vencedor = "";

    // Modos do Cenário (false = Gramado, true = Neon RGB)
    private boolean modoNeon = false;
    private boolean modoSuperRapido = false; // Tecla Ç alterna a velocidade 12
    private int modoTimes = 0; // 0: Real Madrid x Barcelona, 1: Palmeiras x Corinthians, 2: City x United, 3: Brasil x Argentina
    private float hueRGB = 0.0f; // Para animação do RGB

    // Cores dos Times (Real Madrid vs Barcelona)
    private final Color COR_REAL_MADRID = new Color(245, 245, 245);
    private final Color BORDA_REAL_MADRID = new Color(212, 175, 55);

    private final Color COR_BARCELONA = new Color(165, 0, 68);
    private final Color BORDA_BARCELONA = new Color(0, 77, 152);

    // Teclas pressionadas
    private boolean w, s, a, d;
    private boolean cima, baixo, esquerda, direita;

    private Timer timer;

    public Jogofutebolx1() {
        this.setPreferredSize(new Dimension(LARGURA, ALTURA));
        this.setBackground(new Color(34, 139, 34)); // Cor de gramado padrão
        this.setFocusable(true);
        this.addKeyListener(this);

        timer = new Timer(16, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // ================= DESENHAR CAMPO DE JOGO =================
        Color corLinhas;
        if (modoNeon) {
            this.setBackground(Color.BLACK);
            corLinhas = Color.getHSBColor(hueRGB, 1.0f, 1.0f);
            g2d.setStroke(new BasicStroke(3));
        } else {
            this.setBackground(new Color(34, 139, 34));
            corLinhas = Color.WHITE;
            g2d.setStroke(new BasicStroke(1));
        }

        // Desenhar Campo
        g2d.setColor(corLinhas);
        g2d.drawRect(20, 20, LARGURA - 40, ALTURA - 40);
        g2d.drawLine(LARGURA / 2, 20, LARGURA / 2, ALTURA - 20);
        g2d.drawOval(LARGURA / 2 - 50, ALTURA / 2 - 50, 100, 100);

        // Gols (Balizas)
        g2d.drawRect(5, 175, 15, 150);
        g2d.drawRect(LARGURA - 20, 175, 15, 150);

        // Desenhar Jogador 1
        g2d.setColor(modoTimes == 1 ? new Color(0, 130, 60) : modoTimes == 2 ? new Color(108, 190, 235) : modoTimes == 3 ? new Color(255, 210, 0) : COR_REAL_MADRID);
        g2d.fillOval(j1X, j1Y, 40, 40);
        g2d.setColor(modoTimes == 1 ? new Color(255, 220, 0) : modoTimes == 2 ? Color.WHITE : modoTimes == 3 ? new Color(0, 120, 50) : BORDA_REAL_MADRID);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawOval(j1X, j1Y, 40, 40);

        // Desenhar Jogador 2
        g2d.setColor(modoTimes == 1 ? Color.BLACK : modoTimes == 2 ? new Color(220, 35, 45) : modoTimes == 3 ? new Color(110, 190, 235) : COR_BARCELONA);
        g2d.fillOval(j2X, j2Y, 40, 40);
        g2d.setColor(modoTimes == 1 ? Color.WHITE : modoTimes == 2 ? new Color(255, 210, 0) : modoTimes == 3 ? Color.WHITE : BORDA_BARCELONA);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawOval(j2X, j2Y, 40, 40);

        // ================= BOLA COM APARÊNCIA CLÁSSICA (Telstar) =================
        desenharBolaClassica(g2d, bolaX, bolaY, 22);

        // Placar Estilizado
        desenharPlacarDesenvolvido(g2d);
        if (modoSuperRapido && !jogoTerminou) {
            g2d.setFont(new Font("Consolas", Font.BOLD, 14));
            g2d.setColor(Color.YELLOW);
            g2d.drawString("MODO SUPER-RÁPIDO ATIVO (VELOCIDADE 12)", 225, 82);
        }

        // Controles na parte inferior
        g2d.setFont(new Font("Consolas", Font.BOLD, 12));
        g2d.setColor(new Color(240, 240, 240, 220));
        g2d.drawString(nomeTime1() + " (W,A,S,D) vs " + nomeTime2() + " (Setas) | L: Neon | R: Reiniciar | K: Rapido | B: Encerrar", 12, ALTURA - 5);

        // Tela de Fim de Jogo
        if (jogoTerminou) {
            g2d.setColor(new Color(0, 0, 0, 210));
            g2d.fillRect(0, 0, LARGURA, ALTURA);

            g2d.setColor(Color.YELLOW);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 38));
            g2d.drawString("FIM DE JOGO!", LARGURA / 2 - 120, ALTURA / 2 - 40);

            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 26));
            g2d.drawString("Vencedor: " + vencedor, LARGURA / 2 - 160, ALTURA / 2 + 10);

            g2d.setFont(new Font("Consolas", Font.PLAIN, 18));
            g2d.setColor(Color.CYAN);
            g2d.drawString("Pressione R para Jogar Novamente", LARGURA / 2 - 150, ALTURA / 2 + 60);
        }
    }

    private void desenharBolaClassica(Graphics2D g2d, int x, int y, int diametro) {
        // Base da Bola (Branca)
        g2d.setColor(Color.WHITE);
        g2d.fillOval(x, y, diametro, diametro);

        // Pentágono Central
        int cx = x + diametro / 2;
        int cy = y + diametro / 2;
        int rCentral = diametro / 5;

        Polygon pCentral = new Polygon();
        for (int i = 0; i < 5; i++) {
            double ang = Math.toRadians(i * 72 - 90);
            pCentral.addPoint((int)(cx + rCentral * Math.cos(ang)), (int)(cy + rCentral * Math.sin(ang)));
        }

        g2d.setColor(Color.BLACK);
        g2d.fillPolygon(pCentral);

        // Gomos ao redor (Linhas e Pentágonos parciais)
        g2d.setStroke(new BasicStroke(1.2f));
        g2d.setColor(Color.BLACK);

        for (int i = 0; i < 5; i++) {
            double ang = Math.toRadians(i * 72 - 90);
            int px1 = (int)(cx + rCentral * Math.cos(ang));
            int py1 = (int)(cy + rCentral * Math.sin(ang));
            int px2 = (int)(cx + (diametro / 2.1) * Math.cos(ang));
            int py2 = (int)(cy + (diametro / 2.1) * Math.sin(ang));

            // Linha conectando o centro aos pontos externos
            g2d.drawLine(px1, py1, px2, py2);

            // Pequenos detalhes nas bordas para simular gomos pretos externos
            int size = diametro / 6;
            g2d.fillOval((int)(px2 - size / 2.0), (int)(py2 - size / 2.0), size, size);
        }

        // Borda Externa da Bola
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawOval(x, y, diametro, diametro);
    }

    private String nomeTime1() {
        if (modoTimes == 1) return "PALMEIRAS";
        if (modoTimes == 2) return "CITY";
        if (modoTimes == 3) return "BRASIL";
        return "REAL MADRID";
    }

    private String nomeTime2() {
        if (modoTimes == 1) return "CORINTHIANS";
        if (modoTimes == 2) return "UNITED";
        if (modoTimes == 3) return "ARGENTINA";
        return "BARCELONA";
    }

    private String nomeVencedor1() {
        if (modoTimes == 1) return "Palmeiras";
        if (modoTimes == 2) return "Manchester City";
        if (modoTimes == 3) return "Brasil";
        return "Real Madrid";
    }

    private String nomeVencedor2() {
        if (modoTimes == 1) return "Corinthians";
        if (modoTimes == 2) return "Manchester United";
        if (modoTimes == 3) return "Argentina";
        return "FC Barcelona";
    }

    private void desenharPlacarDesenvolvido(Graphics2D g2d) {
        int painelWidth = 340;
        int painelHeight = 55;
        int painelX = (LARGURA - painelWidth) / 2;
        int painelY = 10;

        Color corFundoTop = modoNeon ? new Color(20, 20, 30, 230) : new Color(10, 25, 40, 220);
        Color corFundoBottom = modoNeon ? new Color(5, 5, 10, 240) : new Color(5, 10, 20, 230);
        GradientPaint gp = new GradientPaint(painelX, painelY, corFundoTop, painelX, painelY + painelHeight, corFundoBottom);

        g2d.setPaint(gp);
        g2d.fillRoundRect(painelX, painelY, painelWidth, painelHeight, 20, 20);

        Color corBorda = modoNeon ? Color.getHSBColor(hueRGB, 0.8f, 1.0f) : new Color(212, 175, 55);
        g2d.setStroke(new BasicStroke(2));
        g2d.setColor(corBorda);
        g2d.drawRoundRect(painelX, painelY, painelWidth, painelHeight, 20, 20);

        // Nomes dos Times
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 13));
        g2d.setColor(COR_REAL_MADRID);
        g2d.drawString(nomeTime1(), painelX + 15, painelY + 22);

        g2d.setColor(new Color(255, 120, 150));
        g2d.drawString(nomeTime2(), painelX + painelWidth - (modoTimes == 1 ? 125 : modoTimes == 2 ? 95 : modoTimes == 3 ? 105 : 105), painelY + 22);

        // Placar de Gols
        g2d.setFont(new Font("Consolas", Font.BOLD, 26));
        g2d.setColor(Color.WHITE);
        g2d.drawString(String.format("%02d", golsJ1), painelX + 45, painelY + 47);

        g2d.setFont(new Font("Segoe UI", Font.ITALIC | Font.BOLD, 16));
        g2d.setColor(Color.YELLOW);
        g2d.drawString("VS", painelX + painelWidth / 2 - 10, painelY + 35);

        g2d.setFont(new Font("Consolas", Font.BOLD, 26));
        g2d.setColor(Color.WHITE);
        g2d.drawString(String.format("%02d", golsJ2), painelX + painelWidth - 70, painelY + 47);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        hueRGB += 0.01f;
        if (hueRGB > 1.0f) hueRGB = 0.0f;

        if (jogoTerminou) {
            repaint();
            return;
        }

        // Movimento Jogador 1
        int vel = modoSuperRapido ? 12 : 5;
        if (w && j1Y > 20) j1Y -= vel;
        if (s && j1Y < ALTURA - 60) j1Y += vel;
        if (a && j1X > 20) j1X -= vel;
        if (d && j1X < LARGURA - 60) j1X += vel;

        // Movimento Jogador 2
        if (cima && j2Y > 20) j2Y -= vel;
        if (baixo && j2Y < ALTURA - 60) j2Y += vel;
        if (esquerda && j2X > 20) j2X -= vel;
        if (direita && j2X < LARGURA - 60) j2X += vel;

        // Movimento da Bola
        bolaX += (int) bolaVX;
        bolaY += (int) bolaVY;

        bolaVX *= 0.95;
        bolaVY *= 0.95;

        // Limitações da Bola - Paredes
        if (bolaY <= 20) {
            bolaY = 20;
            bolaVY = -bolaVY;
        } else if (bolaY >= ALTURA - 44) {
            bolaY = ALTURA - 44;
            bolaVY = -bolaVY;
        }

        if (bolaX <= 20) {
            if (bolaY >= 175 && bolaY + 22 <= 325) {
                golsJ2++;
                verificarVencedor();
                resetarPosicoes();
            } else {
                bolaX = 20;
                bolaVX = -bolaVX;
            }
        }

        if (bolaX >= LARGURA - 42) {
            if (bolaY >= 175 && bolaY + 22 <= 325) {
                golsJ1++;
                verificarVencedor();
                resetarPosicoes();
            } else {
                bolaX = LARGURA - 42;
                bolaVX = -bolaVX;
            }
        }

        // Colisão Bola com Jogadores
        if (colisao(j1X, j1Y, 40, bolaX, bolaY, 22)) {
            bolaVX = (bolaX - j1X) / 2.0;
            bolaVY = (bolaY - j1Y) / 2.0;
        }

        if (colisao(j2X, j2Y, 40, bolaX, bolaY, 22)) {
            bolaVX = (bolaX - j2X) / 2.0;
            bolaVY = (bolaY - j2Y) / 2.0;
        }

        repaint();
    }

    private void verificarVencedor() {
        if (golsJ1 >= 5) {
            vencedor = nomeVencedor1();
            jogoTerminou = true;
        } else if (golsJ2 >= 5) {
            vencedor = nomeVencedor2();
            jogoTerminou = true;
        }
    }

    private boolean colisao(int x1, int y1, int tam1, int x2, int y2, int tam2) {
        int centroX1 = x1 + tam1 / 2;
        int centroY1 = y1 + tam1 / 2;
        int centroX2 = x2 + tam2 / 2;
        int centroY2 = y2 + tam2 / 2;

        double distancia = Math.sqrt(Math.pow(centroX1 - centroX2, 2) + Math.pow(centroY1 - centroY2, 2));
        return distancia < (tam1 / 2.0 + tam2 / 2.0);
    }

    private void resetarPosicoes() {
        j1X = 100; j1Y = 220;
        j2X = 660; j2Y = 220;
        bolaX = 389; bolaY = 239;
        bolaVX = 0; bolaVY = 0;
    }

    private void reiniciarJogo() {
        golsJ1 = 0;
        golsJ2 = 0;
        jogoTerminou = false;
        vencedor = "";
        modoSuperRapido = false;
        w = s = a = d = false;
        cima = baixo = esquerda = direita = false;
        resetarPosicoes();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();

        if (k == KeyEvent.VK_R) reiniciarJogo();
        if (k == KeyEvent.VK_L) modoNeon = !modoNeon;
        if (k == KeyEvent.VK_K) modoSuperRapido = !modoSuperRapido;
        if (k == KeyEvent.VK_B && !jogoTerminou) {
            jogoTerminou = true;
            vencedor = golsJ1 > golsJ2 ? nomeVencedor1() :
                       golsJ2 > golsJ1 ? nomeVencedor2() : "Empate";
        }

        if (k == KeyEvent.VK_W) w = true;
        if (k == KeyEvent.VK_S) s = true;
        if (k == KeyEvent.VK_A) a = true;
        if (k == KeyEvent.VK_D) d = true;

        if (k == KeyEvent.VK_UP) cima = true;
        if (k == KeyEvent.VK_DOWN) baixo = true;
        if (k == KeyEvent.VK_LEFT) esquerda = true;
        if (k == KeyEvent.VK_RIGHT) direita = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.VK_W) w = false;
        if (k == KeyEvent.VK_S) s = false;
        if (k == KeyEvent.VK_A) a = false;
        if (k == KeyEvent.VK_D) d = false;

        if (k == KeyEvent.VK_UP) cima = false;
        if (k == KeyEvent.VK_DOWN) baixo = false;
        if (k == KeyEvent.VK_LEFT) esquerda = false;
        if (k == KeyEvent.VK_RIGHT) direita = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    public void setModoTimes(int modo) {
        this.modoTimes = Math.max(0, Math.min(3, modo));
        reiniciarJogo();
        repaint();
    }

    public void pararJogo() {
        timer.stop();
    }

    private static JPanel criarMenu(JFrame frame) {
        JPanel menu = new JPanel(new GridBagLayout());
        menu.setBackground(new Color(12, 18, 34));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(7, 20, 7, 20);

        JLabel titulo = new JLabel("FUTEBOL DOS GOATS", SwingConstants.CENTER);
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        c.gridy = 0;
        c.insets = new Insets(20, 20, 4, 20);
        menu.add(titulo, c);

        JLabel subtitulo = new JLabel("ESCOLHA O CONFRONTO", SwingConstants.CENTER);
        subtitulo.setForeground(new Color(160, 190, 220));
        subtitulo.setFont(new Font("Arial", Font.BOLD, 16));
        c.gridy = 1;
        c.insets = new Insets(0, 20, 18, 20);
        menu.add(subtitulo, c);

        String[] confrontos = {
            "REAL MADRID  x  BARCELONA",
            "PALMEIRAS  x  CORINTHIANS",
            "MANCHESTER CITY  x  MANCHESTER UNITED",
            "BRASIL  x  ARGENTINA"
        };
        Color[] cores = {
            new Color(75, 90, 130), new Color(0, 115, 65),
            new Color(252, 74, 74), new Color(245, 191, 65)
        };
        final int[] selecionado = {0};
        JButton[] botoes = new JButton[confrontos.length];
        for (int i = 0; i < confrontos.length; i++) {
            final int modo = i;
            JButton botao = new JButton(confrontos[i]);
            botao.setFont(new Font("Arial", Font.BOLD, 15));
            botao.setForeground(Color.WHITE);
            botao.setBackground(cores[i]);
            botao.setFocusPainted(false);
            botao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(90, 110, 145), 1),
                BorderFactory.createEmptyBorder(12, 18, 12, 18)));
            botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
            botao.addActionListener(e -> {
                selecionado[0] = modo;
                for (int j = 0; j < botoes.length; j++) {
                    botoes[j].setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(j == modo ? Color.WHITE : new Color(90, 110, 145), j == modo ? 3 : 1),
                        BorderFactory.createEmptyBorder(12, 18, 12, 18)));
                }
            });
            botoes[i] = botao;
            c.gridy = i + 2;
            c.insets = new Insets(6, 45, 6, 45);
            menu.add(botao, c);
        }

        JButton iniciar = new JButton("INICIAR PARTIDA ▶");
        iniciar.setFont(new Font("Arial", Font.BOLD, 16));
        iniciar.setForeground(new Color(10, 20, 30));
        iniciar.setBackground(new Color(80, 220, 150));
        iniciar.setFocusPainted(false);
        iniciar.setBorder(BorderFactory.createEmptyBorder(13, 25, 13, 25));
        iniciar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iniciar.addActionListener(e -> {
            Jogofutebolx1 jogo = new Jogofutebolx1();
            jogo.setModoTimes(selecionado[0]);
            JPanel telaJogo = new JPanel(new BorderLayout());
            JButton voltar = new JButton("← Menu de times");
            voltar.setFont(new Font("Arial", Font.BOLD, 13));
            voltar.addActionListener(ev -> {
                jogo.pararJogo();
                frame.setContentPane(criarMenu(frame));
                frame.pack();
                frame.setLocationRelativeTo(null);
            });
            JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT));
            barra.setBackground(new Color(12, 18, 34));
            barra.add(voltar);
            telaJogo.add(barra, BorderLayout.NORTH);
            telaJogo.add(jogo, BorderLayout.CENTER);
            frame.setContentPane(telaJogo);
            frame.pack();
            frame.setLocationRelativeTo(null);
            jogo.requestFocusInWindow();
        });
        c.gridy = 6;
        c.insets = new Insets(18, 20, 20, 20);
        menu.add(iniciar, c);

        JLabel dicas = new JLabel("WASD: jogador 1   •   Setas: jogador 2   •   R: reiniciar   •   K: velocidade   •   L: neon", SwingConstants.CENTER);
        dicas.setForeground(new Color(170, 180, 200));
        dicas.setFont(new Font("Arial", Font.PLAIN, 11));
        c.gridy = 7;
        c.insets = new Insets(2, 15, 15, 15);
        menu.add(dicas, c);
        return menu;
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Futebol dos GOATS");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(criarMenu(frame));
            frame.pack();
            frame.setMinimumSize(new Dimension(600, 570));
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);
            frame.setVisible(true);
        });
    }
}
